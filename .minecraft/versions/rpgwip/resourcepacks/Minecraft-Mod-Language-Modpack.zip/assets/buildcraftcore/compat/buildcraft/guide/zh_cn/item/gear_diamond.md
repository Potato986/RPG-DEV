<chapter name="item.diamondGearItem.name"/>
<lore>
在你深入的采矿挖掘中，你发现了最稀有且最坚固的材料：钻石。
凭借着自身的强度，钻石齿轮能够完成最苛刻的任务，且不会损坏或磨损。
</lore>
<no_lore>
钻石齿轮作为最终级别的齿轮拥有最佳的性能，它被用于最复杂的机器。
</no_lore>
<recipes_usages stack="buildcraftcore:gear_diamond"/>
