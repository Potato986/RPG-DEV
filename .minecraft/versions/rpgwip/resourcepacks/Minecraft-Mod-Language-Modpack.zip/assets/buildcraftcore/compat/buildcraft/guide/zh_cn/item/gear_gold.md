<chapter name="item.goldGearItem.name"/>
<lore>
更复杂的工作需要大量非常小的连锁齿轮，若在该结构中使用铁齿轮则会很快损坏。
黄金打造的微型齿轮永不损坏，因此它可以用于复杂的机械装置。
</lore>
<no_lore>
黄金齿轮是更高级别的齿轮，用于更大型的机器。
</no_lore>
<recipes_usages stack="buildcraftcore:gear_gold"/>
